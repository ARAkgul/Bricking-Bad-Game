package Domain;

public class RepairingAlien implements Alien {

	public RepairingAlien(int xPos, int yPos, int length, int width) {
		
		this.setType("RepairingAlien");
	}

	public void repairBricks(int xPos, int yPos) {
		
	}

	@Override
	public int getXpos() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getYpos() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getStatus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setStatus(int status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setXpos(int X) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setYpos(int Y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getLength() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getWidth() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setType(String type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disappear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void appear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void perform() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getDir() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setDir(int dir) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isAppeared() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setAppeared(boolean appear) {
		// TODO Auto-generated method stub
		
	}


	
}
