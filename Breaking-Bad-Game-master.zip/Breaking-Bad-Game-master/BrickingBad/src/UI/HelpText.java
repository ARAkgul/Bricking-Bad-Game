package UI;

public class HelpText {
	public String helpText ="<html>    <h1>Monopoly presents;</h1>\r\n" + 
			"    <h4>Bricking Bad</h4>\r\n" +
			"    <h4>Total brick number should be less than 42</h4>\r\n" +
			"    <h4>How to play;</h4>\r\n" + 
			"    <h4>Launching the Ball: Space or Up Arrow</h4>\r\n" + 
			"    <h4>Moving Paddle: Left Arrow - Right Arrow</h4>\r\n" + 
			"    <h4>Rotating Paddle: A-D</h4>\r\n" + 
			"    <h4>Destructive Laser Gun: W</h4>\r\n" + 
			"    <h4>Magnet: M</h4></html>";
}
