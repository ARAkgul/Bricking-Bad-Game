package UI;

import javax.swing.JButton;

public class PauseButton {
	
	
	JButton pause = new JButton();
	
	public PauseButton() {
		pause=new JButton("Pause");
	}
}
